<?php 
require("Funcionario.php");
class gerentee extends Funcionario{
	public function receberSalario(){
		$banco = 1000;
		$banco = $banco * 0.8;

		$this->salario = $banco;
		echo "recebido";
		echo $this->salario;
	}

}




?>