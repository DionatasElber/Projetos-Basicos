<?php 

class funcionario {
	private $nome;
	private $dataAdmicao;
	private $cargo;
	private $dataNacimento;
	private $salario;


	public function receberSalario(){
		$banco = 1000;

		$this->salario = $banco;
		echo $this->salario + "recebido";

	}


	public function setNome($nomeParam){
		$this->$nome = $nomeParam;
	}
	public function getNome(){
		echo $this->$nome;
	}


	public function setDataAdmicao($dataAdmicaoParam){
		$this->dataAdmicao = $dataAdmicaoParam;
	}
	public function getDataAdmicao(){

		echo $this->dataAdmicao;
	}


	public function setCargo($cargoParam){
		$this->cargo = $cargoParam;
	}
	public function getCargo(){
		echo $this->cargo;
	}


	
}







?>