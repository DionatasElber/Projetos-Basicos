<?php 
require("gerente.php");



$pessoa = new gerentee;
$pessoa->receberSalario();




?>