package com.example.petapp.ui.cachorro;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.petapp.R;

public class CachorroFragment extends Fragment {

    private CachorroViewModel cachorroViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        cachorroViewModel =
                ViewModelProviders.of(this).get(CachorroViewModel.class);
        View root = inflater.inflate(R.layout.fragment_cachorro, container, false);
        cachorroViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
            }
        });
        return root;
    }
}