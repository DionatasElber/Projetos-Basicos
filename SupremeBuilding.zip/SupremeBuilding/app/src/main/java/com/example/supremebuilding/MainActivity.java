package com.example.supremebuilding;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    private Button Cliente;
    private Button Contato;
    private Button Investidores;
    private Button PoliticaPrivacidade;
    private Button SobreNos;
    private Button Sustentabilidade;
    private Button TrabalheConosco;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Cliente = findViewById(R.id.clienteID);
        Contato = findViewById(R.id.contatoID);
        Investidores= findViewById(R.id.investidoresID);
        PoliticaPrivacidade= findViewById(R.id.privacidadeID);
        SobreNos = findViewById(R.id.sobreNosID);
        Sustentabilidade= findViewById(R.id.sustentabilidadeID);
        TrabalheConosco= findViewById(R.id.contatoID);

        Cliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Cliente.class));
            }
        });
        Contato.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Contato.class));
            }
        });
        Investidores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Investidores.class));
            }
        });

        PoliticaPrivacidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,PoliticaPrivacidade.class));
            }
        });

        SobreNos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,SobreNos.class));
            }
        });

        Sustentabilidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Sustentabilidade.class));
            }
        });

        TrabalheConosco.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,TrabalheConosco.class));
            }
        });




    }
}
