package com.example.supremebuilding;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class SobreNos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre_nos);
    }
}
